# Peculiar Pioneers language review handoff

Prepared September 14, 2026 for Design Preview 02. These are proposed content changes, not a deployable application or a replacement for the existing repository.

Start with Peculiar_Pioneers_Full_Language_Review.md. Revision_Records.json preserves before/after text. The proposed content JSON files correspond to the inline preview; Proposed_Sanctuary_Lesson.json targets the fuller lesson module in the supplied original source. Timeline_Review.csv lists all 570 original events; 566 remain after the recorded corrections. Quotation_Review.csv lists all 48 timeline placements, including 46 outside the requested source corpus.

Do not publish the remaining historical entries or inherited quotations as independently verified. Most still require primary-source verification; priority concerns appear in the report and timeline ledger. Video recordings and operational/financial claims were not independently verified.

The approved visual design is unchanged. The live website and original repository were not modified. This handoff excludes the inline preview fragment, which is conversation content.
