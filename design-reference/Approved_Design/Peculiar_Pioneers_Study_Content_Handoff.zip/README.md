# Peculiar Pioneers study-content handoff

- `Peculiar_Pioneers_Ten_Bible_Studies.md`: complete readings, reflection prompts, flashcards, questions, answers, explanations, and sources.
- `Peculiar_Pioneers_Study_Content.json`: reusable, framework-independent data for ten studies and seventy learning points.
- `Study_Verification.json`: completed checks and the browser-rendering limitation.

The JSON is content, not a drop-in replacement for an existing React component. Integrate it into the actual repository only after establishing its current baseline. Retain the approved design, KJV links, clear answer feedback, all existing source-reviewed site content, and the dedicated `/prophecy/1844` resource.

Book abbreviations: GC = The Great Controversy (1911); SC = Steps to Christ; MH = The Ministry of Healing; DA = The Desire of Ages; Ed = Education. References use original printed pages, with paragraph numbers when specified.
